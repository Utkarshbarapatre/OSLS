package com.buzzword.osls.service;

import com.buzzword.osls.dto.JwtResponse;
import com.buzzword.osls.dto.LoginRequest;
import com.buzzword.osls.dto.RegisterRequest;
import com.buzzword.osls.model.User;
import com.buzzword.osls.model.enums.Role;
import com.buzzword.osls.repository.UserRepository;
import com.buzzword.osls.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private JwtUtil jwtUtil;

    public String register(RegisterRequest req) {
        if (userRepository.existsByUsername(req.getUsername())) {
            throw new RuntimeException("Username already taken");
        }
        if (userRepository.existsByEmail(req.getEmail())) {
            throw new RuntimeException("Email already registered");
        }

        User user=new User();
        user.setUsername(req.getUsername());
        user.setEmail(req.getEmail());
        user.setPassword(passwordEncoder.encode(req.getPassword()));
        user.setRole(Role.USER);
        userRepository.save(user);
        return "User registered successfully";
    }

    public JwtResponse login(LoginRequest req) {
        Authentication auth=authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword())
        );
        SecurityContextHolder.getContext().setAuthentication(auth);

        String token=jwtUtil.generateToken(req.getUsername());
        User user=userRepository.findByUsername(req.getUsername())
            .orElseThrow(() -> new RuntimeException("User not found"));

        return new JwtResponse(token, user.getId(), user.getUsername(), user.getEmail(), user.getRole().name());
    }

    public JwtResponse adminLogin(LoginRequest req) {
        Authentication auth=authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(req.getUsername(), req.getPassword())
        );

        User user=userRepository.findByUsername(req.getUsername())
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (user.getRole()!=Role.ADMIN) {
            // Do not set the SecurityContext for a rejected admin-login attempt;
            // the credentials were valid but this account has no admin access.
            throw new RuntimeException("This account does not have admin access");
        }

        SecurityContextHolder.getContext().setAuthentication(auth);
        String token=jwtUtil.generateToken(req.getUsername());

        return new JwtResponse(token, user.getId(), user.getUsername(), user.getEmail(), user.getRole().name());
    }
}
