package com.buzzword.osls.controller;

import com.buzzword.osls.dto.ApiResponse;
import com.buzzword.osls.dto.JwtResponse;
import com.buzzword.osls.dto.LoginRequest;
import com.buzzword.osls.dto.RegisterRequest;
import com.buzzword.osls.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody RegisterRequest req) {
        try {
            String msg=authService.register(req);
            return ResponseEntity.ok(new ApiResponse(true, msg));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(new ApiResponse(false, e.getMessage()));
        }
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest req) {
        try {
            JwtResponse jwt=authService.login(req);
            return ResponseEntity.ok(jwt);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(new ApiResponse(false, "Invalid credentials"));
        }
    }

    @PostMapping("/admin-login")
    public ResponseEntity<?> adminLogin(@RequestBody LoginRequest req) {
        try {
            JwtResponse jwt=authService.adminLogin(req);
            return ResponseEntity.ok(jwt);
        } catch (Exception e) {
            return ResponseEntity.status(403).body(new ApiResponse(false, "Invalid credentials or not an admin account"));
        }
    }
}
