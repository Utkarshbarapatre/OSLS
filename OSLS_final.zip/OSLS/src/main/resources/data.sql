-- ============================================================
-- OSLS Dummy Seed Data
-- Runs automatically on app startup (spring.sql.init.mode=always)
-- Uses INSERT IGNORE so re-running on an existing DB is safe.
-- ============================================================

-- ---------------------------------------------
-- Users
--   1) admin   / Admin123!     -> ADMIN role
--   2) jdoe     / Password123!  -> USER role (resource/comment author)
--   3) asmith   / Password123!  -> USER role (second contributor)
-- Passwords are BCrypt-hashed (compatible with Spring Security's
-- BCryptPasswordEncoder). Plaintext is given above for local testing only.
-- ---------------------------------------------
INSERT IGNORE INTO users (id, username, email, password, role, created_at) VALUES
(1, 'admin', 'admin@buzzword.com', '$2a$10$LvZNeBO1eXxPpVE9b9iDF.K7d7bR9o56okxsVY7ykQ0TaJKbqdl1S', 'ADMIN', NOW()),
(2, 'jdoe',  'jdoe@buzzword.com',  '$2a$10$fAd45.e5IPwXb0DHKqtV9OmBU1WTP/m0JwyOfz1GaM9pzEKCSxVW2', 'USER',  NOW()),
(3, 'asmith','asmith@buzzword.com','$2a$10$fAd45.e5IPwXb0DHKqtV9OmBU1WTP/m0JwyOfz1GaM9pzEKCSxVW2', 'USER',  NOW());

-- ---------------------------------------------
-- Resources ("products") — 3 dummy entries covering
-- different ResourceCategory values from the requirements doc
-- ---------------------------------------------
INSERT IGNORE INTO resources (id, title, description, url, category, added_by, created_at, updated_at) VALUES
(1, 'Clean Code: A Handbook of Agile Software Craftsmanship',
    'Open-source-adjacent reference book on writing maintainable, readable code. Widely used as an internal onboarding reference.',
    'https://www.oreilly.com/library/view/clean-code/9780136083238/',
    'BOOK', 1, NOW(), NOW()),

(2, 'The Twelve-Factor App',
    'White paper describing a methodology for building software-as-a-service apps that are portable and resilient when deployed to the cloud.',
    'https://12factor.net/',
    'WHITEPAPER', 2, NOW(), NOW()),

(3, 'OWASP Top Ten',
    'Standard awareness document outlining the most critical security risks to web applications. Used as a baseline for internal security reviews.',
    'https://owasp.org/www-project-top-ten/',
    'STANDARD', 3, NOW(), NOW());

-- ---------------------------------------------
-- Comments — a couple of sample comments per resource
-- ---------------------------------------------
INSERT IGNORE INTO comments (id, content, resource_id, user_id, created_at, updated_at) VALUES
(1, 'Great refresher for new hires — recommend pairing this with our internal style guide.', 1, 2, NOW(), NOW()),
(2, 'Some of the examples feel dated (pre-Java 8), but the core principles still hold up.', 1, 3, NOW(), NOW()),
(3, 'We adopted most of this for our microservices checklist. Config-via-env-vars section is especially relevant.', 2, 1, NOW(), NOW()),
(4, 'Linked this in the new-service template repo so it shows up automatically for new teams.', 3, 1, NOW(), NOW());
