# Open-Source Library System (OSLS)
**Buzzword Software Solutions Limited — Software Development Department**

---

## Tech Stack
- Java 17, Spring Boot 3.2.5, Maven
- Spring Security + JWT (jjwt 0.11.5)
- Spring Data JPA + Hibernate + MySQL
- Vanilla HTML/CSS/JS frontend (MVC pattern)

---

## Setup

### 1. MySQL Database
Make sure MySQL is running locally. The app auto-creates the `osls_db` database.

Default credentials in `application.properties`:
```
spring.datasource.username=root
spring.datasource.password=root
```
Change these to match your local MySQL setup.

### 2. Run the App
```bash
mvn spring-boot:run
```
App starts at: **http://localhost:8080**

### 3. Create Admin User
After registering normally, open MySQL and run:
```sql
USE osls_db;
UPDATE users SET role='ADMIN' WHERE username='your_username';
```

---

## Project Structure
```
src/main/java/com/buzzword/osls/
├── config/         SecurityConfig.java
├── controller/     AuthController, ResourceController, CommentController, AdminController
├── dto/            Request/Response DTOs
├── model/          User, Resource, Comment entities + enums
├── repository/     JPA Repositories
├── security/       JwtUtil, JwtFilter, CustomUserDetailsService
└── service/        AuthService, ResourceService, CommentService, UserService

src/main/resources/static/
├── index.html      Login / Register
├── dashboard.html  Browse & search resources
├── resource.html   Add/Edit resource + comments
├── admin.html      Admin panel
├── css/style.css
└── js/             auth.js, dashboard.js, resource.js, admin.js
```

---

## API Endpoints

| Method | Path | Auth |
|---|---|---|
| POST | /api/auth/register | Public — always creates a USER account |
| POST | /api/auth/login | Public — any role |
| POST | /api/auth/admin-login | Public endpoint, but only succeeds for accounts with role=ADMIN |
| GET | /api/resources | USER |
| GET | /api/resources/search?q=&category= | USER |
| POST | /api/resources | USER |
| PUT | /api/resources/{id} | Owner or ADMIN |
| DELETE | /api/resources/{id} | Owner or ADMIN |
| GET | /api/resources/{id}/comments | USER |
| POST | /api/resources/{id}/comments | USER |
| GET | /api/comments/{id} | USER |
| PUT | /api/comments/{id} | Owner or ADMIN |
| DELETE | /api/comments/{id} | Owner or ADMIN |
| GET | /api/admin/users | ADMIN only |
| DELETE | /api/admin/users/{id} | ADMIN only |
| DELETE | /api/admin/resources/{id} | ADMIN only |
"# OSLS"

---

## Roles & Privileges

Two roles exist: `USER` and `ADMIN`.

- **USER** — can create resources/comments, and edit or delete *only the ones they created*. Cannot reach any `/api/admin/**` endpoint or the admin-login flow.
- **ADMIN** — can do everything a USER can, plus edit or delete *any* user's resources or comments, manage user accounts, and is the only role that can authenticate via `/api/auth/admin-login`.

Ownership vs. admin access is enforced in `ResourceService` / `CommentService` (resource/comment writes), and role-only access is enforced at the security-filter level for `/api/admin/**` in `SecurityConfig`.

**Login endpoints**
- `POST /api/auth/login` — works for both USER and ADMIN accounts, returns a JWT with the account's actual role.
- `POST /api/auth/admin-login` — same request body (`username`, `password`), but rejects the login with `403` if the account's role isn't `ADMIN`, even if the password is correct. Intended for an admin-only login page in the frontend.

Both endpoints issue the same kind of JWT — the token itself doesn't encode "how" the user logged in. Every request still re-checks the caller's role fresh from the database on each call (`CustomUserDetailsService`), so authorization can never go stale even if a user's role changes between logins.

---

## Dummy / Seed Data

`src/main/resources/data.sql` auto-loads on every app startup (`spring.sql.init.mode=always`, applied after Hibernate creates/updates tables via `spring.jpa.defer-datasource-initialization=true`). Inserts use `INSERT IGNORE`, so restarting the app on an existing database won't fail or duplicate rows.

**Users**

| Username | Password | Role |
|---|---|---|
| admin | Admin123! | ADMIN |
| jdoe | Password123! | USER |
| asmith | Password123! | USER |

**Resources ("products")**

| Title | Category | Added by |
|---|---|---|
| Clean Code: A Handbook of Agile Software Craftsmanship | BOOK | jdoe |
| The Twelve-Factor App | WHITEPAPER | asmith |
| OWASP Top Ten | STANDARD | admin |

Each resource also has 1–2 sample comments seeded against it. Log in with any of the accounts above via `POST /api/auth/login` to get a JWT and start testing the other endpoints right away — no manual `UPDATE users SET role='ADMIN'` step needed for the admin account.
